This is an TIVA C library for the DHT series of low cost temperature/humidity sensors. 

Tutorial: http://hocarm.org/energia-bai-8-dht22-tiva-cam-bien-do-am-dat

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder DHT. Check that the DHT folder contains DHT.cpp and DHT.h. Place the DHT library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
